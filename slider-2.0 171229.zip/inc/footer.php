<footer>
<hr/>
    <p class="text-center">
        &copy; 2017<?php echo date('Y') > 2017 ? ' - ' . date('Y') : ''; ?> <a href="index.php" title="Gocciani AB">Gocciani AB</a>.

         <a href="mailto:andreas@gocciani.se">Problem? Maila oss</a> eller ring <a href="tel:0304600060">0304 - 60 00 60</a>
    </p>
</footer>