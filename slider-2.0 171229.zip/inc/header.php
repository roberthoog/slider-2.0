<header>
    <div class="row full">
        <div class="columns small-12 medium-12 large-12">
        <a href="index.php">
            <img src="images/gocc_logo_webb.png" alt="Logo" id="logo">
        </a>
        <nav class="menu text-center">
            <ul class="menu align-center">
                <li>
                    <a href="slider-cities-list.php">
                        Gå till visningssidan &nbsp;&nbsp;
                    </a>
                </li>
                <li>
                    <a href="list-images.php">
                        Visa &amp; redigera bilder&nbsp;&nbsp;
                    </a>
                </li>
                <li>
                        <a href="add-image.php">
                            <i class="f302"></i>&nbsp;&nbsp;Lägg till bild
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>